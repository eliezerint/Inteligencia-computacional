templateImage = imread('fourShapes/circle/5.png');

% Carregue as imagens A, B e C
A = imread('fourShapes/circle/253.png');
B = imread('fourShapes/circle/805.png');
C = imread('fourShapes/circle/985.png');

% Calcule o Coeficiente de Correlação de Pearson entre o "template" e as imagens da mesma classe
pearson1 = corr2(templateImage, A);
pearson2 = corr2(templateImage, B);
pearson3 = corr2(templateImage, C);

% Calcule o Erro Quadrático Médio (MSE) entre o "template" e as imagens da mesma classe
mse1 = immse(templateImage, A);
mse2 = immse(templateImage, B);
mse3 = immse(templateImage, C);

% Exiba os resultados para as imagens da mesma classe
disp('Resultados para imagens da mesma classe:');
disp(['Pearson para imagem A: ', num2str(pearson1)]);
disp(['Pearson para imagem B: ', num2str(pearson2)]);
disp(['Pearson para imagem C: ', num2str(pearson3)]);
disp(['MSE para imagem A: ', num2str(mse1)]);
disp(['MSE para imagem B: ', num2str(mse2)]);
disp(['MSE para imagem C: ', num2str(mse3)]);
