% Carregue as imagens
template = imread('fourShapes/star/3.png'); % Substitua pelo caminho do seu template

% Lista de caminhos das imagens da mesma classe
sameClassImages = {'fourshapes/circle/5.png', 'fourshapes/circle/253.png', 'fourshapes/circle/805.png'}; 

% Lista de caminhos das imagens de classes diferentes
diffClassImages = {'fourshapes/square/57.png', 'fourshapes/square/461.png', 'fourshapes/square/487.png'}; 

% Inicialize os arrays para armazenar os resultados
pearsonSameClass = zeros(1, numel(sameClassImages));
mseSameClass = zeros(1, numel(sameClassImages));

pearsonDiffClass = zeros(1, numel(diffClassImages));
mseDiffClass = zeros(1, numel(diffClassImages));

% Calcule Pearson e EQM para imagens da mesma classe
for i = 1:numel(sameClassImages)
    img = imread(sameClassImages{i});
    
    % Converta as imagens para escala de cinza se necessário
    if size(img, 3) == 3
        img = rgb2gray(img);
    end
    
    % Normalize as imagens
    template = double(template(:));
    img = double(img(:));
    template = (template - mean(template)) / std(template);
    img = (img - mean(img)) / std(img);
    
    % Calcule Pearson
    pearsonSameClass(i) = corr(template, img);
    
    % Calcule o Erro Quadrático Médio (EQM)
    mseSameClass(i) = mean((template - img).^2);
end

% Calcule Pearson e EQM para imagens de classes diferentes
for i = 1:numel(diffClassImages)
    img = imread(diffClassImages{i});
    
    % Converta as imagens para escala de cinza se necessário
    if size(img, 3) == 3
        img = rgb2gray(img);
    end
    
    % Normalize as imagens
    template = double(template(:));
    img = double(img(:));
    template = (template - mean(template)) / std(template);
    img = (img - mean(img)) / std(img);
    
    % Calcule Pearson
    pearsonDiffClass(i) = corr(template, img);
    
    % Calcule o Erro Quadrático Médio (EQM)
    mseDiffClass(i) = mean((template - img).^2);
end

% Exiba os resultados
disp('Coeficientes de Pearson para a mesma classe:');
disp(pearsonSameClass);
disp('MSE para a mesma classe:');
disp(mseSameClass);

disp('Coeficientes de Pearson para classes diferentes:');
disp(pearsonDiffClass);
disp('MSE para classes diferentes:');
disp(mseDiffClass);

