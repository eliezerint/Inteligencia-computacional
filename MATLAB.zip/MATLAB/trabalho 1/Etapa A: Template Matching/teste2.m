% Carregue as imagens
templateImage = imread('fourShapes/triangle/11.png'); % Substitua 'template.jpg' pelo nome do seu arquivo de template
class1Image1 = imread('fourShapes/circle/5.png'); % Substitua 'class1_image1.jpg' pelo nome de sua imagem da classe 1
class1Image2 = imread('fourShapes/circle/253.png'); % Substitua 'class1_image2.jpg' pelo nome de sua imagem da classe 1
class1Image3 = imread('fourShapes/circle/805.png'); % Substitua 'class1_image3.jpg' pelo nome de sua imagem da classe 1

class2Image1 = imread('fourShapes/square/57.png'); % Substitua 'class2_image1.jpg' pelo nome de sua imagem da classe 2
class2Image2 = imread('fourShapes/square/461.png'); % Substitua 'class2_image2.jpg' pelo nome de sua imagem da classe 2
class2Image3 = imread('fourShapes/square/487.png'); % Substitua 'class2_image3.jpg' pelo nome de sua imagem da classe 2

class3Image1 = imread('fourShapes/star/3.png'); % Substitua 'class3_image1.jpg' pelo nome de sua imagem da classe 3
class3Image2 = imread('fourShapes/square/461.png'); % Substitua 'class3_image2.jpg' pelo nome de sua imagem da classe 3
class3Image3 = imread('fourShapes/square/487.png'); % Substitua 'class3_image3.jpg' pelo nome de sua imagem da classe 3

class4Image1 = imread('fourShapes/star/3.png'); % Substitua 'class4_image1.jpg' pelo nome de sua imagem da classe 4
class4Image2 = imread('fourShapes/star/313.png'); % Substitua 'class4_image2.jpg' pelo nome de sua imagem da classe 4
class4Image3 = imread('fourShapes/star/511.png'); % Substitua 'class4_image3.jpg' pelo nome de sua imagem da classe 4

% Calcule o coeficiente de correlação de Pearson entre o template e as imagens
pearsonClass1Image1 = corr2(templateImage, class1Image1);
pearsonClass1Image2 = corr2(templateImage, class1Image2);
pearsonClass1Image3 = corr2(templateImage, class1Image3);

pearsonClass2Image1 = corr2(templateImage, class2Image1);
pearsonClass2Image2 = corr2(templateImage, class2Image2);
pearsonClass2Image3 = corr2(templateImage, class2Image3);

pearsonClass3Image1 = corr2(templateImage, class3Image1);
pearsonClass3Image2 = corr2(templateImage, class3Image2);
pearsonClass3Image3 = corr2(templateImage, class3Image3);

pearsonClass4Image1 = corr2(templateImage, class4Image1);
pearsonClass4Image2 = corr2(templateImage, class4Image2);
pearsonClass4Image3 = corr2(templateImage, class4Image3);

% Calcule o erro quadrático médio entre o template e as imagens
mseClass1Image1 = immse(templateImage, class1Image1);
mseClass1Image2 = immse(templateImage, class1Image2);
mseClass1Image3 = immse(templateImage, class1Image3);

mseClass2Image1 = immse(templateImage, class2Image1);
mseClass2Image2 = immse(templateImage, class2Image2);
mseClass2Image3 = immse(templateImage, class2Image3);

mseClass3Image1 = immse(templateImage, class3Image1);
mseClass3Image2 = immse(templateImage, class3Image2);
mseClass3Image3 = immse(templateImage, class3Image3);

mseClass4Image1 = immse(templateImage, class4Image1);
mseClass4Image2 = immse(templateImage, class4Image2);
mseClass4Image3 = immse(templateImage, class4Image3);

% Exiba os resultados
disp('Pearson Correlation Coefficients:');
disp(['Class 1 Image 1: ' num2str(pearsonClass1Image1)]);
disp(['Class 1 Image 2: ' num2str(pearsonClass1Image2)]);
disp(['Class 1 Image 3: ' num2str(pearsonClass1Image3)]);
disp(['Class 2 Image 1: ' num2str(pearsonClass2Image1)]);
disp(['Class 2 Image 2: ' num2str(pearsonClass2Image2)]);
disp(['Class 2 Image 3: ' num2str(pearsonClass2Image3)]);
disp(['Class 3 Image 1: ' num2str(pearsonClass3Image1)]);
disp(['Class 3 Image 2: ' num2str(pearsonClass3Image2)]);
disp(['Class 3 Image 3: ' num2str(pearsonClass3Image3)]);
disp(['Class 4 Image 1: ' num2str(pearsonClass4Image1)]);
disp(['Class 4 Image 2: ' num2str(pearsonClass4Image2)]);
disp(['Class 4 Image 3: ' num2str(pearsonClass4Image3)]);

disp('Mean Squared Errors:');
disp(['Class 1 Image 1: ' num2str(mseClass1Image1)]);
disp(['Class 1 Image 2: ' num2str(mseClass1Image2)]);
disp(['Class 1 Image 3: ' num2str(mseClass1Image3)]);
disp(['Class 2 Image 1: ' num2str(mseClass2Image1)]);
disp(['Class 2 Image 2: ' num2str(mseClass2Image2)]);
disp(['Class 2 Image 3: ' num2str(mseClass2Image3)]);
disp(['Class 3 Image 1: ' num2str(mseClass3Image1)]);
disp(['Class 3 Image 2: ' num2str(mseClass3Image2)]);
disp(['Class 3 Image 3: ' num2str(mseClass3Image3)]);
disp(['Class 4 Image 1: ' num2str(mseClass4Image1)]);
disp(['Class 4 Image 2: ' num2str(mseClass4Image2)]);
disp(['Class 4 Image 3: ' num2str(mseClass4Image3)]);
