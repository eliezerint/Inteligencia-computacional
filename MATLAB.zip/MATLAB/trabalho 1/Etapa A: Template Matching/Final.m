function calcularMomentosHuEDefinirClasses(directory)
    % Obtém uma lista de pastas dentro do diretório (cada pasta representa uma classe)
    subfolders = dir(directory);
    subfolderNames = {subfolders([subfolders.isdir]).name}; % Lista de nomes das subpastas

    % Remove entradas '.' e '..' que representam diretórios pai
    subfolderNames = subfolderNames(~ismember(subfolderNames, {'.', '..'}));

    % Lista de classes
    classes = subfolderNames; % As classes serão as subpastas encontradas dinamicamente

    % Inicialize listas para armazenar coeficientes de Pearson e MSE
    numClasses = numel(classes);
    pearsonSameClass = zeros(1, numClasses);
    mseSameClass = zeros(1, numClasses);
    pearsonDiffClass = zeros(numClasses, numClasses);
    mseDiffClass = zeros(numClasses, numClasses);

    % Função para calcular o coeficiente de correlação de Pearson
    calculatePearson = @(image1, image2) corr2(image1, image2);

    % Função para calcular o erro quadrático médio
    calculateMSE = @(image1, image2) immse(image1, image2);

    % Loop através das classes
    for classIdx = 1:numClasses
        currentClass = classes{classIdx};

        % Lista de caminhos das imagens da mesma classe
        sameClassImages = dir(fullfile(directory, currentClass, '*.png'));

        % Restante do código para calcular os momentos invariantes de Hu, comparar e armazenar os resultados
        % ...

        % Exemplo de chamada da função exportarMomentosHuParaArquivo para exportar os resultados
        % exportarMomentosHuParaArquivo(directory, 'resultados_momentos_hu1x1.txt');
    end

    % Função para calcular os momentos invariantes de Hu
    function momentos = calcularMomentosInvariantesHu(imagem)
        % Implemente o cálculo dos momentos invariantes de Hu aqui
        % Retorne os momentos como um vetor
    end

    % Função para exportar os momentos invariantes de Hu para um arquivo
    function exportarMomentosHuParaArquivo(diretorioImagens, arquivoResultados)
        % Use a função `dir` para listar todas as imagens no diretório
        imagens = dir(fullfile(diretorioImagens, '*.png')); % Certifique-se de que suas imagens tenham a extensão correta (pode variar)

        % Abra o arquivo de texto para salvar as classificações dos momentos de Hu
        fid = fopen(arquivoResultados, 'w');

        % Loop para calcular e salvar os momentos invariantes de Hu (1x1) para cada imagem
        for i = 1:length(imagens)
            % Carregue a imagem
            imagem = imread(fullfile(diretorioImagens, imagens(i).name));

            % Calcule os momentos invariantes de Hu para a imagem (implemente a função calcularMomentosInvariantesHu)
            momentos = calcularMomentosInvariantesHu(imagem); % Implemente esta função

            % Escreva os momentos e a classe no arquivo de resultados
            fprintf(fid, 'Classe: %s, Imagem %d: ', nomeClasse, i);
            fprintf(fid, '%f ', momentos);
            fprintf(fid, '\n');
        end

        % Feche o arquivo
        fclose(fid);

        % Exiba uma mensagem indicando que os resultados foram salvos
        disp(['Resultados dos momentos de Hu (1x1) salvos em: ', arquivoResultados]);
    end
end
