% Carregue as imagens do diretório "fourShapes"
directory = 'fourShapes/'; % Substitua pelo caminho do seu diretório
fileList = dir(directory);

% Lista de classes
classes = {'circle', 'square', 'star', 'triangle'};

% Função para calcular o coeficiente de correlação de Pearson
% Calcular a semelhança entre duas imagens 0 a 1 uma semelhança e -1 muito
% diferente-- função anonima
calculatePearson = @(image1, image2) corr2(image1, image2);

% Função para calcular o erro quadrático médio
calculateMSE = @(image1, image2) immse(image1, image2);

for classIdx = 1:numel(classes)
    currentClass = classes{classIdx};
    
    % Lista de caminhos das imagens da mesma classe
    sameClassImages = dir([fullfile(directory, currentClass), '/*.png']);
    
    for i = 1:numel(sameClassImages)
        image = imread(fullfile(directory, currentClass, sameClassImages(i).name));
        pearsonCoefficient = calculatePearson(template, image);
        mseValue = calculateMSE(template, image);
        disp(['Pearson Coefficient (' currentClass ') Image ' num2str(i) ': ' num2str(pearsonCoefficient)]);
        disp(['MSE (' currentClass ') Image ' num2str(i) ': ' num2str(mseValue)]);
    end
end

% Exiba os resultados
disp('Coeficientes de Pearson para a mesma classe:');
disp(pearsonSameClass);
disp('MSE para a mesma classe:');
disp(mseSameClass);

disp('Coeficientes de Pearson para classes diferentes:');
disp(pearsonDiffClass);
disp('MSE para classes diferentes:');
disp(mseDiffClass);
