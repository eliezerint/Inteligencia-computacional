% Diretório das imagens
directory = 'Folhas/'; % Substitua pelo caminho do seu diretório

% Obtém uma lista de pastas dentro do diretório (cada pasta representa uma classe)
subfolders = dir(directory);
subfolderNames = {subfolders([subfolders.isdir]).name}; % Lista de nomes das subpastas

% Remove entradas '.' e '..' que representam diretórios pai
subfolderNames = subfolderNames(~ismember(subfolderNames, {'.', '..'}));

% Lista de classes
classes = subfolderNames; % As classes serão as subpastas encontradas dinamicamente

% Número de imagens a serem selecionadas aleatoriamente de cada classe
numImagensAleatorias = 3;

% Tamanho comum para redimensionamento
tamanhoComum = [200, 200]; % Altere para o tamanho desejado

% Inicialize listas para armazenar coeficientes de Pearson e MSE
numClasses = numel(classes);
pearsonSameClass = zeros(1, numClasses);
mseSameClass = zeros(1, numClasses);
pearsonDiffClass = zeros(numClasses, numClasses);
mseDiffClass = zeros(numClasses, numClasses);

% Função para calcular o coeficiente de correlação de Pearson
calculatePearson = @(image1, image2) corr2(image1, image2);

% Função para calcular o erro quadrático médio
calculateMSE = @(image1, image2) immse(image1, image2);

% Loop através das classes de folhas
for classIdx = 1:numClasses
    currentClass = classes{classIdx};
    
    % Lista de caminhos das imagens da mesma classe
    sameClassImages = dir(fullfile(directory, currentClass, '*.jpg'));
    
    % Seleciona aleatoriamente 3 imagens da classe atual
    randomIndices = randperm(numel(sameClassImages), numImagensAleatorias);
    
    for i = 1:numImagensAleatorias
        % Carrega a imagem e redimensiona para o tamanho comum
        image = imread(fullfile(directory, currentClass, sameClassImages(randomIndices(i)).name));
        image = imresize(image, tamanhoComum);
        
        % Use a primeira imagem como template
        if i == 1
            templateImage = image;
        end
        
        % Calcula o coeficiente de Pearson e o erro quadrático médio
        pearsonCoefficient = calculatePearson(templateImage, image);
        mseValue = calculateMSE(templateImage, image);
        
        % Armazena os resultados na matriz correspondente
        pearsonSameClass(classIdx) = pearsonSameClass(classIdx) + pearsonCoefficient;
        mseSameClass(classIdx) = mseSameClass(classIdx) + mseValue;
    end
    
    % Calcule a média dos coeficientes de Pearson e MSE para a mesma classe
    pearsonSameClass(classIdx) = pearsonSameClass(classIdx) / numImagensAleatorias;
    mseSameClass(classIdx) = mseSameClass(classIdx) / numImagensAleatorias;
    
    % Loop através de outras classes para calcular a diferença
    for otherClassIdx = 1:numClasses
        otherClass = classes{otherClassIdx};
        
        if classIdx ~= otherClassIdx
            % Lista de caminhos das imagens da outra classe
            otherClassImages = dir(fullfile(directory, otherClass, '*.jpg'));
            
            % Seleciona aleatoriamente 3 imagens da classe diferente
            randomIndices = randperm(numel(otherClassImages), numImagensAleatorias);
            
            for j = 1:numImagensAleatorias
                % Carrega a imagem e redimensiona para o tamanho comum
                otherImage = imread(fullfile(directory, otherClass, otherClassImages(randomIndices(j)).name));
                otherImage = imresize(otherImage, tamanhoComum);
                
                % Calcula o coeficiente de Pearson e o erro quadrático médio
                pearsonCoefficient = calculatePearson(templateImage, otherImage);
                mseValue = calculateMSE(templateImage, otherImage);
                
                % Armazena os resultados na matriz correspondente
                pearsonDiffClass(classIdx, otherClassIdx) = pearsonDiffClass(classIdx, otherClassIdx) + pearsonCoefficient;
                mseDiffClass(classIdx, otherClassIdx) = mseDiffClass(classIdx, otherClassIdx) + mseValue;
            end
            
            % Calcule a média dos coeficientes de Pearson e MSE para classes diferentes
            pearsonDiffClass(classIdx, otherClassIdx) = pearsonDiffClass(classIdx, otherClassIdx) / numImagensAleatorias;
            mseDiffClass(classIdx, otherClassIdx) = mseDiffClass(classIdx, otherClassIdx) / numImagensAleatorias;
        end
    end
end

% Exiba os resultados finais
disp('Coeficientes de Pearson para a mesma classe:');
disp(pearsonSameClass);
disp('MSE para a mesma classe:');
disp(mseSameClass);

disp('Coeficientes de Pearson para classes diferentes:');
disp(pearsonDiffClass);
disp('MSE para classes diferentes:');
disp(mseDiffClass);
