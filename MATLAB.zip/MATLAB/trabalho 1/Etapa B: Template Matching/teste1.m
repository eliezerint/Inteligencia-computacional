% Diretório das imagens
directory = 'Folhas/'; % Substitua pelo caminho do seu diretório

% Lista de classes
classes = {'Acer_Opalus', 'Acer_Mono', 'Acer_Capillipes'};

% Inicialize listas para armazenar coeficientes de Pearson e MSE
numClasses = numel(classes);
numImages = 3;
pearsonResults = zeros(numImages, numClasses - 1);
mseResults = zeros(numImages, numClasses - 1);

% Função para calcular o coeficiente de correlação de Pearson
calculatePearson = @(image1, image2) corr2(image1, image2);

% Função para calcular o erro quadrático médio
calculateMSE = @(image1, image2) immse(image1, image2);

% Loop através das classes
for classIdx = 1:numClasses
    currentClass = classes{classIdx};
    
    % Lista de caminhos das imagens da mesma classe
    sameClassImages = dir(fullfile(directory, currentClass, '*.jpg'));
    
    % Carregue o template da primeira imagem da classe atual
    template = imread(fullfile(directory, currentClass, sameClassImages(1).name));
    
    % Loop através das outras classes
    for otherClassIdx = 1:numClasses
        if classIdx ~= otherClassIdx
            otherClass = classes{otherClassIdx};
            
            % Lista de caminhos das imagens de outra classe
            otherClassImages = dir(fullfile(directory, otherClass, '*.jpg'));
            
            % Loop através das três primeiras imagens de outra classe
            for i = 1:numImages
                otherImage = imread(fullfile(directory, otherClass, otherClassImages(i).name));
                pearsonCoefficient = calculatePearson(template, otherImage);
                mseValue = calculateMSE(template, otherImage);
                disp(['Pearson Coefficient (' currentClass ' vs. ' otherClass ') Image ' num2str(i) ': ' num2str(pearsonCoefficient)]);
                disp(['MSE (' currentClass ' vs. ' otherClass ') Image ' num2str(i) ': ' num2str(mseValue)]);
                
                % Armazene os resultados na matriz correspondente
                pearsonResults(i, otherClassIdx) = pearsonCoefficient;
                mseResults(i, otherClassIdx) = mseValue;
            end
        end
    end
end

% Exiba os resultados finais
disp('Coeficientes de Pearson entre o "template" e as três primeiras imagens de outras classes:');
disp(pearsonResults);
disp('MSE entre o "template" e as três primeiras imagens de outras classes:');
disp(mseResults);
