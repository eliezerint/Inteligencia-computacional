% Diretório das imagens
directory = 'fourShapes/'; % Substitua pelo caminho do seu diretório

% Número de imagens a serem selecionadas aleatoriamente de cada classe
numImagensAleatorias = 3;

% Inicialize listas para armazenar coeficientes de Pearson e MSE
subfolders = dir(directory);
subfolderNames = {subfolders([subfolders.isdir]).name}; % Lista de nomes das subpastas

% Remove entradas '.' e '..' que representam diretórios pai
subfolderNames = subfolderNames(~ismember(subfolderNames, {'.', '..'}));

% Lista de classes
classes = subfolderNames; % As classes serão as subpastas encontradas dinamicamente

numClasses = numel(classes);
pearsonSameClass = zeros(1, numClasses);
mseSameClass = zeros(1, numClasses);
pearsonDiffClass = zeros(numClasses, numClasses);
mseDiffClass = zeros(numClasses, numClasses);

% Função para calcular o coeficiente de correlação de Pearson
calculatePearson = @(image1, image2) corr2(image1, image2);

% Função para calcular o erro quadrático médio
calculateMSE = @(image1, image2) immse(image1, image2);

% Loop através das classes
for classIdx = 1:numClasses
    currentClass = classes{classIdx};
    
    % Lista de caminhos das imagens da mesma classe
    sameClassImages = dir(fullfile(directory, currentClass, '*.png'));
    
    % Seleciona aleatoriamente 3 índices de imagens da classe atual
    randomIndices = randperm(numel(sameClassImages), numImagensAleatorias);
    
    % Carrega a imagem de referência da mesma classe (a primeira imagem selecionada)
    referenceImage = imread(fullfile(directory, currentClass, sameClassImages(randomIndices(1)).name));
    
    % Exiba o nome da imagem selecionada como template
    disp('------------');
    disp(['Imagem de referência para ' currentClass ': ' sameClassImages(randomIndices(1)).name]);
    disp('');
    
    for i = 1:numImagensAleatorias
        % Carrega a imagem
        image = imread(fullfile(directory, currentClass, sameClassImages(randomIndices(i)).name));
        
        pearsonCoefficient = calculatePearson(referenceImage, image);
        mseValue = calculateMSE(referenceImage, image);
        
        disp(' ');
        disp(['Pearson Coefficient (' currentClass ') Image ' num2str(i) ': ' num2str(pearsonCoefficient)]);
        disp(['MSE (' currentClass ') Image ' num2str(i) ': ' num2str(mseValue)]);
        
        % Armazene os resultados na matriz correspondente
        pearsonSameClass(classIdx) = pearsonSameClass(classIdx) + pearsonCoefficient;
        mseSameClass(classIdx) = mseSameClass(classIdx) + mseValue;
    end
    
    % Calcule a média dos coeficientes de Pearson e MSE para a mesma classe
    pearsonSameClass(classIdx) = pearsonSameClass(classIdx) / numImagensAleatorias;
    mseSameClass(classIdx) = mseSameClass(classIdx) / numImagensAleatorias;
    
    % Loop através de outras classes para calcular a diferença
    for otherClassIdx = 1:numClasses
        otherClass = classes{otherClassIdx};
        
        if classIdx ~= otherClassIdx
            % Lista de caminhos das imagens de outra classe
            otherClassImages = dir(fullfile(directory, otherClass, '*.png'));
            
            for j = 1:numImagensAleatorias
                % Seleciona aleatoriamente 3 índices de imagens da classe diferente
                randomIndicesOther = randperm(numel(otherClassImages), numImagensAleatorias);
                
                % Carrega a imagem
                otherImage = imread(fullfile(directory, otherClass, otherClassImages(randomIndicesOther(j)).name));
                
                pearsonCoefficient = calculatePearson(referenceImage, otherImage);
                mseValue = calculateMSE(referenceImage, otherImage);
                
                disp(' ');
                disp(['Pearson Coefficient (' currentClass ' vs. ' otherClass ') Image ' num2str(j) ': ' num2str(pearsonCoefficient)]);
                disp(['MSE (' currentClass ' vs. ' otherClass ') Image ' num2str(j) ': ' num2str(mseValue)]);
                
                % Armazene os resultados na matriz correspondente
                pearsonDiffClass(classIdx, otherClassIdx) = pearsonDiffClass(classIdx, otherClassIdx) + pearsonCoefficient;
                mseDiffClass(classIdx, otherClassIdx) = mseDiffClass(classIdx, otherClassIdx) + mseValue;
            end
            
            % Calcule a média dos coeficientes de Pearson e MSE para classes diferentes
            pearsonDiffClass(classIdx, otherClassIdx) = pearsonDiffClass(classIdx, otherClassIdx) / numImagensAleatorias;
            mseDiffClass(classIdx, otherClassIdx) = mseDiffClass(classIdx, otherClassIdx) / numImagensAleatorias;
        end
    end
end

% Exiba os resultados finais
disp('Coeficientes de Pearson para a mesma classe:');
disp(pearsonSameClass);
disp('MSE para a mesma classe:');
disp(mseSameClass);

disp('Coeficientes de Pearson para classes diferentes:');
disp(pearsonDiffClass);
disp('MSE para classes diferentes:');
disp(mseDiffClass);
