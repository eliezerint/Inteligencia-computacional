function count = contarPixels(imagem,tonalidade)
  img = imagem;
  pixels_acima_do_limiar = img > tonalidade;
  count = sum(pixels_acima_do_limiar(:));
end