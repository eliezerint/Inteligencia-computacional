data = dir('fourShapes_2/');

for i = 3:length(data)

    currentFile = data(i);

    if currentFile.isdir
        disp([currentFile.name ': ' num2str(i)]);
        currentFileName = fullfile(currentFile.folder, currentFile.name);
        imageFiles = dir(fullfile(currentFileName, '*.png'))

        for j = 1:length(imageFiles)

            currentImageFile = imageFiles(j);
            currentImageFileName = fullfile(currentImageFile.folder, currentImageFile.name);
            currentImage = imread(currentImageFileName);

            if size(currentImage, 3) == 3
                currentImage = rgb2gray(currentImage);
            end

            disp('moments = imageMoments(currentImage);');

            huMoments = invmoments(currentImage,2,2);

            disp('Momentos Invariantes de HU:');
            disp(huMoments);
            
           disp(contarPixels(currentImage,10));
           
        end
    end

    disp(['Tamanho ' currentFile.name ': ' num2str(length(data))]);
end



