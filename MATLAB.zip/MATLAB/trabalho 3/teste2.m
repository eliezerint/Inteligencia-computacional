% Ler uma imagem (substitua 'imagem.jpg' pelo caminho da sua imagem)
imagem = imread('imagem.jpg');

% Converter a imagem para escala de cinza, se necessário
if size(imagem, 3) == 3
    imagem = rgb2gray(imagem);
end

% Calcular os momentos de imagem
moments = imageMoments(imagem);

% Calcular os momentos invariantes de HU
huMoments = invMoments(moments);

% Exibir os momentos invariantes de HU
disp('Momentos Invariantes de HU:');
disp(huMoments);

% Função para calcular os momentos da imagem
function m = imageMoments(image)
    [rows, cols] = size(image);
    m = zeros(3, 3);
    for p = 1:3
        for q = 1:3
            for x = 1:rows
                for y = 1:cols
                    m(p, q) = m(p, q) + (x^p) * (y^q) * double(image(x, y));
                end
            end
        end
    end
end

% Função para calcular os momentos invariantes de HU
function hu = invMoments(m)
    hu = zeros(1, 7);
    eta = zeros(3, 3);
    for p = 1:3
        for q = 1:3
            eta(p, q) = m(p, q) / (m(1, 1)^(1 + (p + q) / 2));
        end
    end
    hu(1) = eta(2, 0) + eta(0, 2);
    hu(2) = (eta(2, 0) - eta(0, 2))^2 + 4 * eta(1, 1)^2;
    hu(3) = (eta(3, 0) - 3 * eta(1, 2))^2 + (3 * eta(2, 1) - eta(0, 3))^2;
    hu(4) = (eta(3, 0) + eta(1, 2))^2 + (eta(2, 1) + eta(0, 3))^2;
    hu(5) = (eta(3, 0) - 3 * eta(1, 2)) * (eta(3, 0) + eta(1, 2)) * ...
            ((eta(3, 0) + eta(1, 2))^2 - 3 * (eta(2, 1) + eta(0, 3))^2) + ...
            (3 * eta(2, 1) - eta(0, 3)) * (eta(2, 1) + eta(0, 3)) * ...
            (3 * (eta(3, 0) + eta(1, 2))^2 - (eta(2, 1) + eta(0, 3))^2);
    hu(6) = (eta(2, 0) - eta(0, 2)) * ((eta(3, 0) + eta(1, 2))^2 - (eta(2, 1) + eta(0, 3))^2) + ...
            4 * eta(1, 1) * (eta(3, 0) + eta(1, 2)) * (eta(2, 1) + eta(0, 3));
    hu(7) = (3 * eta(2, 1) - eta(0, 3)) * (eta(3, 0) + eta(1, 2)) * ...
            ((eta(3, 0) + eta(1, 2))^2 - 3 * (eta(2, 1) + eta(0, 3))^2) - ...
            (eta(3, 0) - 3 * eta(1, 2)) * (eta(2, 1) + eta(0, 3)) * ...
            (3 * (eta(3, 0) + eta(1, 2))^2 - (eta(2, 1) + eta(0, 3))^2);
end
