function momentosPorZona = calcularMomentosPorZona(imagem, numZonasHorizontais, numZonasVerticais)
% Calcula os momentos de Hu para cada zona da imagem

[linhas, colunas] = size(imagem);
tamanhoZonaHorizontal = fix(linhas / numZonasHorizontais);
tamanhoZonaVertical = fix(colunas / numZonasVerticais);

momentosPorZona = cell(numZonasHorizontais, numZonasVerticais);

for i = 1:numZonasHorizontais
    for j = 1:numZonasVerticais
        % Define as coordenadas da zona
        linhaInicio = (i - 1) * tamanhoZonaHorizontal + 1;
        linhaFim = i * tamanhoZonaHorizontal;
        colunaInicio = (j - 1) * tamanhoZonaVertical + 1;
        colunaFim = j * tamanhoZonaVertical;

        % Extrai a zona da imagems
        zona = imagem(linhaInicio:linhaFim, colunaInicio:colunaFim);

        % Calcula os momentos de Hu para a zona atual
        momentos = invmoments(zona);


        formato = sprintf('%%0.%df', 4);
        valor_formatado = sprintf(formato, momentos(1));
        % Armazena os momentos da zona atual
        teste= '';
        %momentosPorZona = horzcat(cell2mat(momentosPorZona), cell2mat([momentos(1),momentos(2),momentos(3),momentos(4),momentos(5)]);
        %momentosPorZona{i, j} = momentos;
        %momentosPorZona(i, j, :) = momentos(1:7);
    end
end
end
