% Carregue seu conjunto de dados
dados = load('resultados_momentos_hu2x2.txt');

% Divisão do conjunto de dados (60% treinamento, 40% teste)
numAmostras = dados(:, end);
cv = cvpartition(numAmostras, 'HoldOut', 0.4); % 40% para teste

% Índices de treinamento e teste
trainIdx = dados(cv.training,:);
testIdx = dados(cv.test,:);

% Conjuntos de treinamento e teste
conjuntoTreinamento = trainIdx(:, 1: end-1) ;
conjuntoTeste = testIdx(:, 1: end-1) ;
classeTreinamento = trainIdx(:, end) ;
classeTeste = testIdx(:, end) ;

% Parâmetros para momentos invariantes de Hu
numZonasHorizontais = [2, 4, 6, 8]; % Varie o número de zonas horizontais
numZonasVerticais = [2, 4, 6, 8];   % Varie o número de zonas verticais

% Abra o arquivo de resultados para escrita
arquivoResultado = fopen('resultados.txt', 'w');

melhorPrecisao = 0; % Variável para acompanhar o melhor resultado

for h = numZonasHorizontais
    for v = numZonasVerticais
        % Calcule os momentos invariantes de Hu para o conjunto de treinamento
        momentosTreinamento = invmoments(conjuntoTreinamento);
        
        % Calcule os momentos invariantes de Hu para o conjunto de teste
        momentosTeste = invmoments(conjuntoTeste);
        
     % Classificação com k-NN (k = 1, distância euclidiana) 
            modeloKNN = fitcknn(conjuntoTreinamento, classeTreinamento(), 'NumNeighbors', 1, 'Distance', 'euclidean');

        classePredita = predict(modeloKNN, momentosTeste);
        
        % Avaliação do desempenho
        verdadeiros_positivos = sum(classePredita == 1 & classeTeste == 1);
        falsos_positivos = sum(classePredita == 1 & classeTeste == 0);
        precisao = verdadeiros_positivos / (verdadeiros_positivos + falsos_positivos);
        
        % Escreva os resultados no arquivo de resultados
        fprintf(arquivoResultado, 'Zonas Horizontais: %d, Zonas Verticais: %d, Precisão: %.4f\n', h, v, precisao);
        
        % Verifique se é o melhor resultado até agora
        if precisao > melhorPrecisao
            melhorPrecisao = precisao;
            melhoresParametros = [h, v];
        end
    end
end

% Feche o arquivo de resultados
fclose(arquivoResultado);

disp(['Melhor Precisão: ', num2str(melhorPrecisao)]);
disp(['Melhores Parâmetros (Zonas Horizontais x Verticais): ', num2str(melhoresParametros)]);
