function momentos = transforms(imagem,numZonas1,numZonas2)
%TRANSFORMS Summary of this function goes here
%   Detailed explanation goes here

% Defina o número de zonas desejado (por exemplo, 2x2)
numZonasHorizontais = numZonas1;
numZonasVerticais = numZonas2;

% Divida a imagem em zonas
[linhas, colunas] = size(imagem);
tamanhoZonaHorizontal = fix(linhas / numZonasHorizontais);
tamanhoZonaVertical = fix(colunas / numZonasVerticais);

momentosTotais = [];

for i = 1:numZonasHorizontais
    for j = 1:numZonasVerticais
        % Calcule os momentos invariantes de Hu para cada zona
        zona = imagem(1 + (i - 1) * tamanhoZonaHorizontal:i * tamanhoZonaHorizontal, ...
                      1 + (j - 1) * tamanhoZonaVertical:j * tamanhoZonaVertical);
        momentosZona = invmoments(zona);

        % Concatene os momentos da zona aos momentos totais
        momentosTotais = [momentosZona];
    end
end

momentos=momentosTotais;
end

