function exportarMomentosHuParaArquivo(diretorioImagens, arquivoResultados, numZonas)
classes = {'1_circle', '2_square', '3_star', '4_triangle'}; % Lista de classes

% Abra o arquivo de texto para salvar as classificações dos momentos de Hu
fid = fopen(arquivoResultados, 'w');

for i = 1:length(classes)
    classeAtual = classes{i};

    % Use a função `dir` para listar todas as imagens no diretório da classe atual
    imagens = dir(fullfile(diretorioImagens, classeAtual, '/*.png'));
    % Loop para calcular e salvar os momentos invariantes de Hu para cada imagem

    count = (i - 1) * 1000 + 1;

    for j = 1:length(imagens)

        % Carregue a imagem
        imagem = imread(fullfile(diretorioImagens, classeAtual, imagens(j).name));

        disp(fullfile(diretorioImagens, classeAtual, imagens(j).name));

        % Calcule os momentos invariantes de Hu para a images
        %momentos = transforms(imagem, numZonas, numZonas);
        
        numZonasHorizontais = 2;
        numZonasVerticais = 2;
        momentos = calcularMomentosPorZona(imagem, numZonasHorizontais, numZonasVerticais);

        disp(momentos);
        % Escreva a classe, o número da imagem e os momentos no arquivo de resultados
        fprintf(fid, '%i ', count);
        fprintf(fid, '%f ', momentos(1));
        fprintf(fid, '%i ', i);
        fprintf(fid, '\n');

        count = count + 1;
    end
end

% Feche o arquivo
fclose(fid);

% Exiba uma mensagem indicando que os resultados foram salvos
disp(['Resultados dos momentos de Hu salvos em: ', arquivoResultados]);
end
