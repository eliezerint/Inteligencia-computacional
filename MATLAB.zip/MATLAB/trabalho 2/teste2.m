diretorioImagens = 'fourShapes_2/';
arquivoResultados = 'resultados_momentos_hu5x5.txt';
exportarMomentosHuParaArquivo(diretorioImagens, arquivoResultados, 5);
