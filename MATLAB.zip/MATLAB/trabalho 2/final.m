% Carregue seu conjunto de dados
dados = load('resultados_momentos_hu4x4.txt');

% Divisão do conjunto de dados (60% treinamento, 40% teste)
numAmostras = dados(:, end);
cv = cvpartition(numAmostras, 'HoldOut', 0.8); % 40% para teste

% Índices de treinamento e teste
trainIdx = dados(cv.training,:);
testIdx = dados(cv.test,:);

% Conjuntos de treinamento e teste
conjuntoTreinamento = trainIdx(:, 1: end-1);
conjuntoTeste = testIdx(:, 1: end-1);
classeTreinamento = trainIdx(:, end);
classeTeste = testIdx(:, end);

% Normalização Z-score
conjuntoTreinamento = zscore(conjuntoTreinamento);
conjuntoTeste = zscore(conjuntoTeste);

% Abra o arquivo de resultados para escrita
arquivoResultado = fopen('resultados.txt', 'w');

melhorPrecisao = 0; % Variável para acompanhar o melhor resultado

% Classificação com k-NN (k = 1, distância euclidiana)
modeloKNN = fitcknn(conjuntoTreinamento, classeTreinamento, 'NumNeighbors', 1, 'Distance', 'euclidean');

classePredita = predict(modeloKNN, conjuntoTeste);

% Avaliação do desempenho - Precisão (Accuracy)
precisao = sum(classePredita == classeTeste) / length(classeTeste);

% Métricas usando classperf
metrics = classperf(classeTeste, classePredita);
accuracy = metrics.CorrectRate;

% Cálculo do F1-score
f1score = (2 * metrics.Specificity * metrics.Sensitivity) / (metrics.Specificity + metrics.Sensitivity);

% Escreva os resultados no arquivo de resultados
fprintf(arquivoResultado, 'Precisão (Accuracy): %.4f\n', precisao);
fprintf(arquivoResultado, 'Score: %.4f\n', f1score);

% Feche o arquivo de resultados
fclose(arquivoResultado);

disp(['Precisão (Accuracy): ', num2str(precisao)]);
disp(['Score: ', num2str(f1score)]);
